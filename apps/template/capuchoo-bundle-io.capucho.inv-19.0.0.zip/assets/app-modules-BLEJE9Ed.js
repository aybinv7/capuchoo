var e=`assets/icon-b577b700.png`;export{e as t};
//# sourceMappingURL=app-modules-BLEJE9Ed.js.map